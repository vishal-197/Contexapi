import React from 'react'
import About from './About'
import Products from './Products'

function Main() {
  return (
    <>
    <About/>
    <Products/>

   
    </>
    
    
  )
}

export default Main